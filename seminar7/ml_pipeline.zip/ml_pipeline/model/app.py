from fastapi import FastAPI
import numpy as np
import torch
from typing import List

app = FastAPI(title="Model Service")

class DummyModel:
    """Фиктивная модель, возвращающая случайные вероятности"""
    
    def __init__(self, num_classes: int = 10):
        self.num_classes = num_classes
    
    def predict(self, tensor: List[List[List[List[float]]]]) -> List[float]:
        """
        Принимает тензор и возвращает случайные вероятности
        """
        # Игнорируем входной тензор для демонстрации
        # Генерируем случайные вероятности, которые суммируются в 1
        probabilities = np.random.random(self.num_classes)
        probabilities = probabilities / probabilities.sum()
        return probabilities.tolist()

# Инициализируем модель
model = DummyModel(num_classes=10)

@app.post("/predict")
async def predict(tensor_data: dict):
    """
    Принимает тензор и возвращает вероятности классов
    """
    try:
        tensor = tensor_data.get("normalized_tensor", [])
        
        # Выполняем "инференс"
        probabilities = model.predict(tensor)
        
        return {
            "status": "success",
            "probabilities": probabilities,
            "predicted_class": int(np.argmax(probabilities)),
            "model_info": "dummy_model_v1"
        }
        
    except Exception as e:
        return {"status": "error", "message": str(e)}

@app.get("/health")
async def health_check():
    """Проверка состояния сервиса"""
    return {
        "status": "healthy",
        "service": "model",
        "model_type": "dummy",
        "num_classes": 10
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
