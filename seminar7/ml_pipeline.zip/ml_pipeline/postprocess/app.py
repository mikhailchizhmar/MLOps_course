from fastapi import FastAPI
import numpy as np
import requests
from typing import List, Dict

app = FastAPI(title="Postprocess Service")

PREPROCESS_SERVICE_URL = "http://preprocess:8000/process"

@app.post("/postprocess")
async def postprocess_full(file_data: dict = None):
    """
    Полный пайплайн: вызывает preprocess -> model -> postprocess
    """
    try:
        # Отправляем запрос в preprocess сервис
        if file_data:
            response = requests.post(PREPROCESS_SERVICE_URL, json=file_data, timeout=30)
        else:
            # Если нет данных, создаем тестовый запрос
            test_payload = {"test": True}
            response = requests.post(PREPROCESS_SERVICE_URL, json=test_payload, timeout=30)
        
        response.raise_for_status()
        pipeline_result = response.json()
        
        # Извлекаем probabilities из результата model сервиса
        model_result = pipeline_result.get("model_result", {})
        probabilities = model_result.get("probabilities", [])
        
        if not probabilities:
            return {
                "status": "error", 
                "message": "No probabilities received from model"
            }
        
        # Постобработка - находим индекс максимума
        max_index = int(np.argmax(probabilities))
        max_probability = float(probabilities[max_index])
        
        # Дополнительная информация для наглядности
        class_mapping = {
            0: "airplane", 1: "automobile", 2: "bird", 3: "cat", 4: "deer",
            5: "dog", 6: "frog", 7: "horse", 8: "ship", 9: "truck"
        }
        
        class_name = class_mapping.get(max_index, "unknown")
        
        return {
            "status": "success",
            "pipeline": "preprocess -> model -> postprocess",
            "final_prediction": {
                "predicted_class_index": max_index,
                "predicted_class_name": class_name,
                "confidence": max_probability
            },
            "raw_probabilities": probabilities,
            "processing_steps": pipeline_result
        }
        
    except requests.exceptions.RequestException as e:
        return {"status": "error", "message": f"Preprocess service unavailable: {str(e)}"}
    except Exception as e:
        return {"status": "error", "message": str(e)}

@app.post("/postprocess_only")
async def postprocess_only(prediction_data: dict):
    """
    Только постобработка без вызова других сервисов
    """
    try:
        probabilities = prediction_data.get("probabilities", [])
        
        if not probabilities:
            return {"status": "error", "message": "No probabilities provided"}
        
        # Находим индекс максимальной вероятности
        max_index = int(np.argmax(probabilities))
        max_probability = float(probabilities[max_index])
        
        # Дополнительная информация для наглядности
        class_mapping = {
            0: "airplane", 1: "automobile", 2: "bird", 3: "cat", 4: "deer",
            5: "dog", 6: "frog", 7: "horse", 8: "ship", 9: "truck"
        }
        
        class_name = class_mapping.get(max_index, "unknown")
        
        return {
            "status": "success",
            "predicted_class_index": max_index,
            "predicted_class_name": class_name,
            "confidence": max_probability,
            "all_probabilities": probabilities
        }
        
    except Exception as e:
        return {"status": "error", "message": str(e)}

@app.get("/health")
async def health_check():
    """Проверка состояния сервиса"""
    try:
        # Проверяем доступность preprocess сервиса
        response = requests.get("http://preprocess:8000/health", timeout=5)
        preprocess_status = "available" if response.status_code == 200 else "unavailable"
        
        return {
            "status": "healthy",
            "service": "postprocess",
            "dependencies": {
                "preprocess_service": preprocess_status
            }
        }
    except requests.exceptions.RequestException:
        return {
            "status": "degraded",
            "service": "postprocess",
            "dependencies": {
                "preprocess_service": "unavailable"
            }
        }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
