from fastapi import FastAPI, File, UploadFile, HTTPException
from PIL import Image
import io
import numpy as np
import torch
import requests
from typing import List

app = FastAPI(title="Preprocess Service")

MODEL_SERVICE_URL = "http://model:8000/predict"

@app.post("/process")
async def process_image(file: UploadFile = File(...)):
    """
    Принимает изображение, preprocessing и отправляет в model сервис
    """
    # Проверяем, что файл является изображением
    if not file.content_type.startswith('image/'):
        raise HTTPException(status_code=400, detail="File must be an image")
    
    try:
        # Читаем изображение
        contents = await file.read()
        image = Image.open(io.BytesIO(contents)).convert('RGB')
        
        # Ресайз до стандартного размера
        image = image.resize((224, 224))
        
        # Конвертируем в numpy array и нормализуем
        image_array = np.array(image) / 255.0
        
        # Трансформируем в формат [C, H, W] и добавляем batch dimension
        tensor = torch.from_numpy(image_array).permute(2, 0, 1).float()
        tensor = tensor.unsqueeze(0)  # [1, 3, 224, 224]
        
        # Нормализация по каналам
        mean = torch.tensor([0.485, 0.456, 0.406]).view(1, 3, 1, 1)
        std = torch.tensor([0.229, 0.224, 0.225]).view(1, 3, 1, 1)
        normalized_tensor = (tensor - mean) / std
        
        # Конвертируем в список для JSON сериализации
        tensor_list = normalized_tensor.tolist()
        
        # Отправляем данные в model сервис
        payload = {
            "normalized_tensor": tensor_list,
            "tensor_shape": list(normalized_tensor.shape)
        }
        
        try:
            response = requests.post(MODEL_SERVICE_URL, json=payload, timeout=30)
            response.raise_for_status()
            model_result = response.json()
            
            return {
                "status": "success",
                "preprocess": {
                    "tensor_shape": list(normalized_tensor.shape),
                    "processing_complete": True
                },
                "model_result": model_result
            }
            
        except requests.exceptions.RequestException as e:
            raise HTTPException(status_code=503, detail=f"Model service unavailable: {str(e)}")
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error processing image: {str(e)}")

@app.post("/preprocess")
async def preprocess_only(file: UploadFile = File(...)):
    """
    Только preprocessing без отправки в model
    """
    if not file.content_type.startswith('image/'):
        raise HTTPException(status_code=400, detail="File must be an image")
    
    try:
        contents = await file.read()
        image = Image.open(io.BytesIO(contents)).convert('RGB')
        image = image.resize((224, 224))
        image_array = np.array(image) / 255.0
        
        tensor = torch.from_numpy(image_array).permute(2, 0, 1).float()
        tensor = tensor.unsqueeze(0)
        
        mean = torch.tensor([0.485, 0.456, 0.406]).view(1, 3, 1, 1)
        std = torch.tensor([0.229, 0.224, 0.225]).view(1, 3, 1, 1)
        normalized_tensor = (tensor - mean) / std
        
        tensor_list = normalized_tensor.tolist()
        
        return {
            "status": "success",
            "tensor_shape": list(normalized_tensor.shape),
            "normalized_tensor": tensor_list
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error processing image: {str(e)}")

@app.get("/health")
async def health_check():
    """Проверка состояния сервиса"""
    try:
        # Проверяем доступность model сервиса
        response = requests.get("http://model:8000/health", timeout=5)
        model_status = "available" if response.status_code == 200 else "unavailable"
        
        return {
            "status": "healthy",
            "service": "preprocess",
            "dependencies": {
                "model_service": model_status
            }
        }
    except requests.exceptions.RequestException:
        return {
            "status": "degraded",
            "service": "preprocess",
            "dependencies": {
                "model_service": "unavailable"
            }
        }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
